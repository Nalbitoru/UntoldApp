package com.example.untold;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UntoldApplication {

    public static void main(String[] args) {
        SpringApplication.run(UntoldApplication.class, args);
    }

}
