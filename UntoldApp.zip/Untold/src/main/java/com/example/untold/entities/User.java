package com.example.untold.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // generate a value for each id
    private Long id;
    private String username;
    private String password;
    private String type;

    @OneToMany(mappedBy = "user")
    private List<Ticket> tickets = new ArrayList<>();




}
