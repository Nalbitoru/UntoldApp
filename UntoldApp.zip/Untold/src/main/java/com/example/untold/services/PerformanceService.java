package com.example.untold.services;

import com.example.untold.entities.Performance;
import com.example.untold.entities.Place;
import com.example.untold.entities.Ticket;
import com.example.untold.entities.User;
import com.example.untold.repositories.PerformanceRepository;
import com.example.untold.repositories.TicketRepository;
import com.example.untold.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PerformanceService {
    private final PerformanceRepository performanceRepository;
    private final TicketRepository ticketRepository;
    private final UserRepository userRepository;

    @Autowired
    public PerformanceService(PerformanceRepository performanceRepository, TicketRepository ticketRepository, UserRepository userRepository) {
        this.performanceRepository = performanceRepository;
        this.ticketRepository = ticketRepository;
        this.userRepository = userRepository;
    }

    public List<Performance> getAllPerformances() {

        return performanceRepository.findAll();
    }

    public Performance getPerformanceByTitle(String title) {

        return performanceRepository.findPerformanceByTitle(title);
    }

    public Performance savePerformance(String title, String genre, String dateOfShow, int maxTickets) {
        Performance performance = new Performance();
        performance.setTitle(title);
        performance.setGenre(genre);
        performance.setDate_of_show(dateOfShow);
        performance.setMaximum_tickets(maxTickets);
        return performanceRepository.save(performance);
    }

    public Performance updatePerformance(String oldTitle, String newTitle, String newGenre, String new_date_of_show) {

        Performance performance = getPerformanceByTitle(oldTitle);
        performance.setTitle(newTitle);
        performance.setGenre(newGenre);
        performance.setDate_of_show(new_date_of_show);
        return performanceRepository.save(performance);
    }

    public Performance deletePerformanceByTitle(String title) {

        return performanceRepository.deletePerformanceByTitle(title);
    }

    public Ticket releaseTicket(String performanceTitle, String username, List<Place> places) {

        Performance performance = getPerformanceByTitle(performanceTitle);
        User user = userRepository.findUserByUsername(username);
        Ticket ticket = new Ticket();
        ticket.setUser(user);
        ticket.setPlaces(places);
        performance.getTickets().add(ticket);
        performanceRepository.save(performance);
        return ticket;
    }

    public List<Ticket> getAllTicketsByPerformance(String performanceTitle) {

        return getPerformanceByTitle(performanceTitle).getTickets();
    }

    public Ticket updateTicket(Long id, String username, List<Place> places) {

        Optional<Ticket> ticket = ticketRepository.findById(id);

        if (ticket.isPresent()) {

            User user = userRepository.findUserByUsername(username);
            ticket.get().setUser(user);
            ticket.get().setPlaces(places);
        }
        return ticketRepository.save(ticket.get());
    }

    public void deleteTicket(Long id){

        ticketRepository.deleteById(id);
    }


}
