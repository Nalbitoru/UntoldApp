package com.example.untold.services;

import com.example.untold.entities.User;
import com.example.untold.repositories.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service//clasa de tip service
@Transactional
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<User> getAllUsers() {

        return userRepository.findAll();
    }

    public User getUserByUsername(String username) {

        return userRepository.findUserByUsername(username);
    }

    public User saveUser(String username, String password, String type){
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setType(type);

        return userRepository.save(user);
    }

    public User updateUser(String oldUsername, String newUsername, String newPassword, String newType) {

        User user = getUserByUsername(oldUsername);
        user.setPassword(newPassword);
        user.setType(newType);
        user.setUsername(newUsername);
        return userRepository.save(user);
    }

    public void deleteUserByUsername(String username) {

        userRepository.deleteUserByUsername(username);
    }


}
