package com.example.untold.controllers;

import com.example.untold.entities.User;
import com.example.untold.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController//este clasa controller
@RequestMapping(value = "/user")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/users")
    public List<User> getAllUsers() {

        return userService.getAllUsers();
    }

    @GetMapping("/username")
    public User getUserByUsername(@RequestParam("username") String username) {

        return userService.getUserByUsername(username);
    }

    @GetMapping("/save")
    public User saveUser(@RequestParam("username") String username,
                         @RequestParam("password") String password,
                         @RequestParam("type") String type){
        return userService.saveUser(username, password, type);
    }

    @GetMapping("/update")
    public User updateUser(@RequestParam("oldUsername") String oldUsername,
                           @RequestParam("newUsername") String newUsername,
                           @RequestParam("newPassword") String newPassword,
                           @RequestParam("newType") String newType) {
        return userService.updateUser(oldUsername, newUsername, newPassword, newType);
    }

    @GetMapping(value = "/delete")
    public void deleteUserByUsername(@RequestParam("username") String username) {
        userService.deleteUserByUsername(username);
    }
}
