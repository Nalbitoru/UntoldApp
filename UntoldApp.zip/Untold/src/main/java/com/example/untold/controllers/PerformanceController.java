package com.example.untold.controllers;

import com.example.untold.entities.Performance;
import com.example.untold.entities.Place;
import com.example.untold.entities.Ticket;
import com.example.untold.services.PerformanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/performance")
public class PerformanceController {

    private final PerformanceService performanceService;

    @Autowired
    public PerformanceController(PerformanceService performanceService) {
        this.performanceService = performanceService;
    }

    @GetMapping("/performances")
    public List<Performance> getAllPerformances() {
        return performanceService.getAllPerformances();
    }

    @GetMapping("/title")
    public Performance getPerformanceByTitle(@RequestParam("title") String title) {
        return performanceService.getPerformanceByTitle(title);
    }

    @GetMapping("/save")
    public Performance savePerformance(@RequestParam("title") String title,
                                       @RequestParam("genre") String genre,
                                       @RequestParam("date") String dateOfShow,
                                       @RequestParam("maxTickets") int maxTickets) {
        return performanceService.savePerformance(title, genre, dateOfShow, maxTickets);
    }

    @GetMapping("/update")
    public Performance updatePerformance(@RequestParam("oldTitle") String oldTitle,
                                         @RequestParam("newTitle") String newTitle,
                                         @RequestParam("newGenre") String newGenre,
                                         @RequestParam("new_date_of_show") String new_date_of_show) {
        return performanceService.updatePerformance(oldTitle, newTitle, newGenre, new_date_of_show);
    }

    @GetMapping("/delete")
    public Performance deletePerformanceByTitle(@RequestParam("title") String title) {
        return performanceService.deletePerformanceByTitle(title);
    }

    @GetMapping("/ticket/release")
    public Ticket releaseTicket(@RequestParam("performanceTitle") String performanceTitle,
                                @RequestParam("username") String username,
                                @RequestParam("places") List<Place> places) {
        return performanceService.releaseTicket(performanceTitle, username, places);
    }

    @GetMapping("/tickets")
    public List<Ticket> getTicketsByPerformance(@RequestParam("performanceTitle") String performanceTitle) {
        return performanceService.getAllTicketsByPerformance(performanceTitle);
    }

    @GetMapping("/ticket/update")
    public Ticket updateTicket(@RequestParam("id") Long id,
                               @RequestParam("username") String username,
                               @RequestParam("places") List<Place> places) {
        return performanceService.updateTicket(id, username, places);
    }

    @GetMapping("/ticket/delete")
    public void deleteTicket(@RequestParam("id") Long id) {
        performanceService.deleteTicket(id);
    }
}
