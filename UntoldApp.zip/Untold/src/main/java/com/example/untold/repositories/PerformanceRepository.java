package com.example.untold.repositories;

import com.example.untold.entities.Performance;
import com.example.untold.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PerformanceRepository extends JpaRepository<Performance,Long> {

    Performance findPerformanceByTitle(String title);
    Performance deletePerformanceByTitle(String title);
}
